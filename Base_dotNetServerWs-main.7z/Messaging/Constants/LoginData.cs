namespace GameServer.Messaging
{
    public struct LoginData
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}