﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Messaging.Constants
{
    public static class MessageNoti
    {
        public static string  ACCOUNT_EXITS = "Tài khoản đã tồn tại!";
        public static string  ACCOUNT_REGISTER_SUCCESS = "Đăng ký Tài khoản thành công!";
        public static string  ACCOUNT_LOGIN_SUCCESS = "Đăng nhập thành công!";
        public static string  ACCOUNT_LOGIN_FAILED = "Đăng nhập thất bại!";
    }
}
