namespace GameServer.Messaging
{
    public struct RegisterData
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string RePassword { get; set; }
    }
}