namespace GameServer.Messaging
{
    public enum Tags
    {
        LOGIN = 1,
        REGISTER = 2,
        NOTIFICATION = 3,
        
    }
}