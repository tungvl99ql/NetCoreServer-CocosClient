﻿namespace GameServer.Handler
{
    public class WsGameServerBase
    {
    }
}