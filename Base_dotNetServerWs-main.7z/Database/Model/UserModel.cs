﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Database.Model
{
    public class UserModel
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string _id { get; set; }
        public string UserName { get; set; } //  ten dang nhap
        public string PassWord { get; set; } // password dang nhap
        public string DisplayName { get; set; } // ten hien thi
        public string PhoneNumber { get; set; } //  so dien thoai
        public int Vip { get; set; } // cap vip
        public int Gold { get; set; } // don vi tien 1
        public int Diamond { get; set; } //  don vi tien 2
        public string AddressWallet { get; set; }  //  dia chi vi eth ( bsc,polygon..)
        public int Role { get; set; } //  quyen truy cap (-1 blocked,0- user, 1-reporter, 2-admin)
    }
}
