﻿using GameServer.Database.Interface;
using GameServer.Database.Model;
using GameServer.Messaging.Constants;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Database.DataContext
{
    public class UserContext : IUser
    {
        public readonly IMongoDatabase _db;
        public UserContext(IMongoDatabase db)
        {
            _db = db;
        }
        public IMongoCollection<UserModel> Usercollection => _db.GetCollection<UserModel>("user");

        public long CountUser()
        {
            throw new NotImplementedException();
        }

        public async Task<BaseResult> CreateUser(UserModel user)
        {
            var _user = Usercollection.Find(x => x.UserName == user.UserName).FirstOrDefault();
            if (_user == null)
            {
                // tai khoan chua ton tai
                //Usercollection.InsertMany(user);
               await Usercollection.InsertOneAsync(user);
                return new BaseResult
                {
                    Tags = Messaging.Tags.REGISTER,
                    Success = true,
                    Message = MessageNoti.ACCOUNT_REGISTER_SUCCESS,
                };
            }
            else
            {
                //Console.WriteLine("tai khoan da ton tai");
                return new BaseResult
                {
                    Tags = Messaging.Tags.REGISTER,
                    Success = false,
                    Message = MessageNoti.ACCOUNT_EXITS,
                };
            }
            
        }

        public IEnumerable<UserModel> GetTopUserDiamond()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<UserModel> GetTopUserGold()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<UserModel> GetTopUserVip()
        {
            throw new NotImplementedException();
        }

        public BaseResult GetUser(string username)
        {
            var user =  Usercollection.Find(x => x.UserName == username).FirstOrDefault();
            if(user == null)
            {
                var result = new BaseResult
                {
                    Tags = Messaging.Tags.LOGIN,
                    Success = false,
                    Message = MessageNoti.ACCOUNT_LOGIN_FAILED,
                    Data = null
                };
                return result;
            }
            else
            {
                var result = new BaseResult
                {
                    Tags = Messaging.Tags.LOGIN,
                    Success = true,
                    Message = MessageNoti.ACCOUNT_LOGIN_SUCCESS,
                    Data = user,
                };
                return result;
            }
        }
    }
}
