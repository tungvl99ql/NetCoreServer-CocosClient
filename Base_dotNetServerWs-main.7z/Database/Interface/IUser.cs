﻿using GameServer.Database.Model;
using GameServer.Messaging.Constants;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameServer.Database.Interface
{
    internal interface IUser
    {
        IMongoCollection<UserModel> Usercollection { get; }
        long CountUser();
        IEnumerable<UserModel> GetTopUserGold();
        IEnumerable<UserModel> GetTopUserDiamond();
        IEnumerable<UserModel> GetTopUserVip();
        BaseResult GetUser(string username);

        Task<BaseResult> CreateUser(UserModel user);
    }
}
