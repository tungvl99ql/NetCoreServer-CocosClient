﻿using GameServer.Handler;
using GameServer.Interface;
using MongoDB.Driver;
using System;
using System.Net;

namespace GameServer
{
    class Program
    {
        static void Main(string[] args)
        {
            IGameLogger logger = new Logger();

            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("Game");
            var Playermanager = new PlayerManager(logger, database);

            var wsServer = new WsGameServer(IPAddress.Any, 8080, Playermanager, logger, database);
            wsServer.StartGameServer();
            logger.Infor("Server Start!");
            for(; ; )
            {
                var type = Console.ReadLine();
                if(type == "restart")
                {
                    wsServer.RestartGameServer();
                }
                if (type == "stop")
                {
                    wsServer.StopGameServer();
                }
            }
        }
    }
}
